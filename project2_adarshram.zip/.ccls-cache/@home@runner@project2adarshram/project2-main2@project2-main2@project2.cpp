/*
 * project2.cpp
 *
 * The implementation file where you will implement your code for Project 2.
 *
 * INSTRUCTOR NOTE: Do not change any of the existing function signatures in
 * this file. You may add helper functions for
 * any function other than Sum in Question 1.
 */

#include "project2.h"
#include "recursive_list.h"

/** QUESTION 1: SUM AND PRODUCT **/

// EFFECTS: returns the sum of each element in list, or zero if the list is
//          empty
// Your implementation of Sum should NOT be tail recursive and should NOT
// use a helper function.

// PSEUDOCODE:
// algorithm sum
//   if ListIsEmpty(list) then
//   return 0
//   or else  
//   return Sum(ListRest(list)) plus ListFirst(list);

int Sum(RecursiveList list) {
  if (ListIsEmpty(list))
    return 0;

  return Sum(ListRest(list)) + ListFirst(list);
}

// EFFECTS: returns the product of each element in list, or one if the list is
//          empty

// PSEUDOCODE:
// algorithm Product
//   if ListIsEmpty(list) then
//   return 1
//   or else
//   return Sum(ListRest(list)) times ListFirst(list);

int Product(RecursiveList list) {
  if (ListIsEmpty(list))
    return 1;

  return Product(ListRest(list)) * ListFirst(list);
}

/** QUESTION 2: TAIL RECURSIVE SUM **/

// EFFECTS: adds the next element in the list to the sum so far
// Your implementation of TailRecursiveSumHelper MUST be tail recursive.

// PSEUDOCODE:
// algorithm TailRecursiveSumHelper
//   if ListIsEmpty(list) then
//   return sum_so_far
//   add sum_so_far to ListFirst(list)
//   return TailRecursiveSumHelper(ListRest(list), sum_so_far)

int TailRecursiveSumHelper(RecursiveList list, int sum_so_far) {
  if (ListIsEmpty(list))
    return sum_so_far;
  sum_so_far += ListFirst(list);
  return TailRecursiveSumHelper(ListRest(list), sum_so_far);
}

// EFFECTS: returns the sum of each element in list, or zero if the list is
//          empty
// THIS FUNCTION IS PROVIDED AS PART OF THE STARTER CODE.
// DO NOT MODIFY THIS FUNCTION.

// PSEUDOCODE:
// algorithm TailRecursiveSum
//   return TailRecursiveSumHelper(list, 0)

int TailRecursiveSum(RecursiveList list) {
  return TailRecursiveSumHelper(list, 0);
}

/** QUESTION 3: FILTER ODD AND FILTER EVEN **/

// EFFECTS: returns a new list containing only the elements of the original list
//          which are odd in value, in the order in which they appeared in list
// For example, FilterOdd(( 4 1 3 0 )) would return the list ( 1 3 )

// PSEUDOCODE:
// algorithm FilterOdd
//   if ListIsEmpty(list) then
//     return the list
//   else if ListFirst(list) has a remainder divided by 2 then
//     return new MakeList(ListFirst(list), FilterOdd(ListRest(list)))
//   else
//      return rest of list through FilterOdd(ListRest(list))

RecursiveList FilterOdd(RecursiveList list) {
  if (ListIsEmpty(list))
    return list;
  else if (ListFirst(list) % 2 == 1)
    return MakeList(ListFirst(list), FilterOdd(ListRest(list)));
  else
    return FilterOdd(ListRest(list));
}

// EFFECTS: returns a new list containing only the elements of the original list
//          which are even in value, in the order in which they appeared in list
// For example, FilterEven(( 4 1 3 0 )) would return the list ( 4 0 )

// PSEUDOCODE:
// algorithm FilterEven
//   if ListIsEmpty(list) then
//     return the list
//   else if ListFirst(list) has a remainder divided by 2 then
//     return new MakeList(ListFirst(list), FilterEven(ListRest(list)))
//   else
//      return rest of list through FilterEven(ListRest(list))

RecursiveList FilterEven(RecursiveList list) {
  if (ListIsEmpty(list))
    return list;
  else if (ListFirst(list) % 2 == 0)
    return MakeList(ListFirst(list), FilterEven(ListRest(list)));
  else
    return FilterEven(ListRest(list));
}

/** QUESTION 4: REVERSE **/

// EFFECTS: returns the reverse of list
// For example, the reverse of ( 3 2 1 ) is ( 1 2 3 )

// PSEUDOCODE:
// algorithm ReverseHelper
//    if ListIsEmpty(list) then
//      return the listx
//  listx equals MakeList(ListFirst(list), listx)
//  return ReverseHelper(ListRest(list), listx) then

// algorithm Reverse
//  utilize Reverse(RecursiveList list)
//  RecursiveList empty equals MakeList()
//  return ReverseHelper(list, empty)

RecursiveList ReverseHelper(RecursiveList list, RecursiveList listx) {
  if (ListIsEmpty(list) == true) {
    return listx;
  }
  listx = MakeList(ListFirst(list), listx);
  return ReverseHelper(ListRest(list), listx);
}

RecursiveList Reverse(RecursiveList list) {
  RecursiveList empty = MakeList();
  return ReverseHelper(list, empty);
}

/** QUESTION 5: APPEND **/

// EFFECTS: returns the list (first_list second_list)
// For example, if first_list is ( 1 2 3 ) and second_list is ( 4 5 6 ), then
// returns ( 1 2 3 4 5 6 )
//
// PSEUDOCODE:
// algorithm Append
//   if first_list is empty then
//      return second_list
//  else if second_list is empty then
//      return first_list
//  else
//      return MakeList(first_lists first element),Append(ListRest(first_list), second_list))

RecursiveList Append(RecursiveList first_list, RecursiveList second_list) {
  if (ListIsEmpty(first_list))
    return second_list;
  else if (ListIsEmpty(second_list))
    return first_list;

  else
    return MakeList(ListFirst(first_list),
                    Append(ListRest(first_list), second_list));
}

/** QUESTION 6: CHOP **/

// REQUIRES: list has at least n elements
// EFFECTS: returns the list equal to list without its last n elements

// PSEUDOCODE:
//   algorithm ChopHelper
//      if n value equals 0 then
//      return the list
//      else
//      return ChopHelper(rest of the list), n - 1 to decrement index)

//   algorithm Chop
//      return Reverse(ChopHelper(Reverse(list), n))

RecursiveList ChopHelper(RecursiveList list, unsigned int n) {
  if (n == 0)
    return list;
  return ChopHelper(ListRest(list), (n - 1));
}

RecursiveList Chop(RecursiveList list, unsigned int n) {
  return Reverse(ChopHelper(Reverse(list), n));
}

/** QUESTION 7: ROTATE **/

// EFFECTS: returns a list equal to the original list with the
//          first element moved to the end of the list n times.
// For example, Rotate(( 1 2 3 4 5 ), 2) yields ( 3 4 5 1 2 )

// PSEUDOCODE:
// algorithm Rotate
//  if n equals 0 then
//    return list
//  if n equals 1 then
//    rotate list by Append(ListRest(list) to new list of only first element)
//    else
//    return rototed append ListRest(list) and MakeList(first element of list)
//    empty list (MakeList())), and n - 1 to decrement index

RecursiveList Rotate(RecursiveList list, unsigned int n) {
  if (n == 0)
    return list;
  if (n == 1)
    return(Append(ListRest(list), MakeList(ListFirst(list), MakeList())));
  return Rotate(Append(ListRest(list), MakeList(ListFirst(list), MakeList())), n - 1);
}

/** QUESTION 8: INSERT LIST **/

// REQUIRES: n <= the number of elements in first_list
// EFFECTS: returns a list comprising the first n elements of first_list,
//          followed by all elements of second_list, followed by any remaining
//          elements of "first_list"
// For example, InsertList (( 1 2 3 ), ( 4 5 6 ), 2) returns ( 1 2 4 5 6 3 )

// PSEUDOCODE:
// algorithm InsertList
//  if n equals 0 then
//    Append(second_list, to first_list)
//  if n equals 1 then
//    Append(first element of first_list to rest of first_list)
//  else
//    MakeList(first element of first list) call 
//    InsertList((remainder of first list), second list, and n - 1 to decrement index)

RecursiveList InsertList(RecursiveList first_list, RecursiveList second_list, unsigned int n) {
  if (n == 0)
		return Append(second_list, first_list);
	if (n == 1)
		return Append(MakeList(ListFirst(first_list), second_list), ListRest(first_list)); 
	  return MakeList(ListFirst(first_list), InsertList(ListRest(first_list), second_list, n-1));
}