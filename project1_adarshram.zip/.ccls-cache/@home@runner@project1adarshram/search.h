#ifndef SEARCH_H
#define SEARCH_H

int LinearSearch(int numbers[], int length, int n);
int BinarySearch(int numbers[], int length, int n);

#endif