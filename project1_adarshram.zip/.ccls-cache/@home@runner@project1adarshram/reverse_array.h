#ifndef REVERSE_ARRAY_H
#define REVERSE_ARRAY_H

void ReverseArray(int arr[], int length);

#endif