/**
PSEUDOCODE:

algorithm ReverseArray
  Input: An array of integers and its length
  Output: Reverse of the array
  Side Effect: The array will be reversed

  algorithm ReverseArray
    Set start = 0
    Set end = length - 1

    while start < end
      Set temp to the value of arr[start]
      Set arr[start] = value of arr[end]
      Set arr[end] = value of temp
    
    Increment start by 1
    Decrement end by 1

COMMENTS:
*/

void ReverseArray(int arr[], int length) {
  // Implement this function.
  int start = 0;
  int end = length - 1;

  while (start < end) {
    int temp = arr[start];

    arr[start] = arr[end];
    arr[end] = temp;

    start++;
    end--;
  }
}