#include <string>

/**
PSEUDOCODE:

algorithm MinimumWordLength
  Input: An array of common words
  Output: Length of the shortest word in the list

  algorithm MinimumWordLength
    minLength = words[0].length()
    Declare i = 0

    if length == 0 then
        return 0
    end if
    i < length
        if words[i].length() < minLength then
            set minLength = words[i].length()
       if
        set i = i + 1
    end while
    return minLength

COMMENTS:
*/

int MinimumWordLength(std::string words[], int length) {
  // Implement this function.
  if (length == 0) {
    return 0;
  }
  int minLength = words[0].length();
  for (int i = 0; i < length; i++) {
    if (words[i].length() < minLength) {
      minLength = words[i].length();
    }
  }
  return minLength;
}

/**
PSEUDOCODE:

algorithm MaximumWordLength
  Input: An array of common words
  Output: Length of the longest word in the list

  algorithm MaximumWordLength
    maxLength = 0
    Declare i = 0
    if length == 0 then
        return 0
    end if
    i < length
        if words[i].length() > maxLength then
            set maxLength = words[i].length()
        end if
        set i = i + 1
    end while
    return maxLength

COMMENTS:
*/

int MaximumWordLength(std::string words[], int length) {
  // Implement this function.
  if (length == 0) {
    return 0;
  }
  int maxLength = 0;
  for (int i = 0; i < length; i++) {
    if (words[i].length() > maxLength) {
      maxLength = words[i].length();
    }
  }
  return maxLength;
}

/**
PSEUDOCODE:

algorithm RangeOfWordLengths
  Input: An array of common words
  Output: Range of lengths in the word list

  algorithm RangeOfWordLengths
    maxLength = MaximumWordLength(words, length)
    minLength = MinimumWordLength(words, length)

    if length == 0 then
        return 0
    end if
  return maxLength - minLength

COMMENTS:
*/

int RangeOfWordLengths(std::string words[], int length) {
  // Implement this function.

  if (length == 0) {
    return 0;
  }
  return MaximumWordLength(words, length) - MinimumWordLength(words, length);
}

/**
PSEUDOCODE:

algorithm WordLengthMean
  Input: An array of common words
  Output: Average word length in the word list

  algorithm WordLengthMean
    average = 0
    Declare i = 0

    if length == 0 then
        return 0
    end if
    while i < length
        add words[i].length() to average
        set i = i + 1
    end while

    return average / length

COMMENTS:
*/

int WordLengthMean(std::string words[], int length) {
  // Implement this function.
  if (length == 0) {
    return 0;
  }

  int avg = 0;
  for (int i = 0; i < length; i++) {
    avg += words[i].length();
  }
  return avg / length;
}

/**
PSEUDOCODE:

algorithm WordLengthMode
  Input: An array of common words
  Output: The most common length of the words in the list

  algorithm WordLengthMode
    initialize tempWord = 0
    initialize tempCount = 0

    For loop to iterate through the input array of strings words
    count number of occurrences of string = count

    end while
    if count > tempCount
      tempCount = count:
      tempWord = words[array]

    end if
    return tempWord
    return 0

COMMENTS:
I wasn't able to return -1 for a tie. I was thinking I could create another loop reading the array but in the reverse direction. Then find the second mode andset that mode equal to the first mode. If the first mode == the second mode (in terms of amount not value) then the code should output -1.
*/

int WordLengthMode(std::string words[], int length) {
  // Implement this function.

  int tempWord = 0;
  int tempCount = 0;

  for (int i = 0; i < length; i++) {

    int count = 0;
    for (int j = 0; j < length; j++) {
      if (words[j] == words[i])
        count++;
    }
    if (count > tempCount) {
      tempCount = count;
      tempWord = words[i].length();
      }
      else if(words[i].length() == tempCount) {
        tempWord = -1;
    }
  }
  return tempWord;
  return 0;
}