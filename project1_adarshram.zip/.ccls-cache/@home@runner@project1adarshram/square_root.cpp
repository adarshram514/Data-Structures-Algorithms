#include <iomanip>
#include <iostream>
#include <sstream>
#include <string>

/**
THIS FUNCTION IS PROVIDED AS PART OF THE STARTER CODE.
DO NOT MODIFY THIS FUNCTION.
*/
std::string ConvertFloatToStr(float n, int precision) {
  std::stringstream ss;
  ss << std::fixed << std::setprecision(precision) << n;
  return ss.str();
}

/**
PSEUDOCODE:

algorithm ApproxSqrt
  Input: Integer n to find the square root of n
  Output: Floating point number approximating the square root of n

  lower_bound = 0
  upper_bound = n

  algorithm ApproxSqrt
    Create loop for iteration
    guess = (lower_bound + upper_bound) / 2.0
    if guess^ 2 == n:
      return guess
    else if guess^2 < n:
      lower_bound = guess
    else:
      upper_bound = guess

  return guess
*/

std::string ApproxSqrt(int n, int iterations) {
  // Implement this function.
  // You may call ConvertFloatToStr as part of your solution.
  float lower_bound = 0.0;
  float upper_bound = n;
  float guess;

  for (int i = 0; i < iterations; i++) {
    
    guess = (lower_bound + upper_bound) / 2.0;
    if (guess * guess == n) {
      return ConvertFloatToStr(guess, 10);
    } 
    else if (guess * guess < n) {
      lower_bound = guess;
    } 
    else {
      upper_bound = guess;
    }
  }
  return ConvertFloatToStr(guess, 10);
}