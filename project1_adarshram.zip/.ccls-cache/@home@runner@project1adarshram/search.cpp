/**
PSEUDOCODE:

algorithm LinearSearch
  Input: Integer array, Integer query
  Output: Integer representing index of query in array

  algorithm LinearSearch
    for index in range(0, array size - 1):
      if A[index] == query:
        return index

    return -1
*/

int LinearSearch(int numbers[], int length, int n) {
  // Implement this function.
  for (int i = 0; i < length; i++) {
    if (numbers[i] == n) {
      return i;
    }
  }
  return -1;
}

/**
PSEUDOCODE:

algorithm BinarySearch
  Input: A sorted array of integers and a specific integer to search for
  Output: An integer representing the index

algorithm BinarySearch
  lower_bound = 0;
  upper_bound = array size - 1;

  while (lower_bound =< upper_bound):
    guess = (lower_bound + upper_bound)/2
    if array [guess] == query:
      return guess
    else if array [guess] < query :
      lower_bound = guess + 1
    else:
      upper_bound = guess - 1

  return -1

COMMENTS:
This pseudocode is based on the lecture slides went over in class
*/

int BinarySearch(int numbers[], int length, int n) {
  // Implement this function.
  int lower_bound = 0;
  int upper_bound = length - 1;

  while (lower_bound <= upper_bound) {
    int guess = (lower_bound + upper_bound) / 2;
    if (numbers[guess] == n) {
      return guess;
    } 
    else if (numbers[guess] < n) {
      lower_bound = guess + 1;
    } 
    else {
      upper_bound = guess - 1;
    }
  }
  return -1;
}